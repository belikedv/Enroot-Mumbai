<?php

// Settings
$settings = array(
    "name"          => "Name",
    "email"         => "example@domain.com",
);

require_once "phpmailer/contact_form.php";